/**********************************
  * IFPB - Curso Superior de Tec. em Sist. para Internet
 * POB - Persistencia de Objetos
 * Prof. Fausto Ayres
 *
 */

package appconsole;



import modelo.Componente;

import modelo.Orcamento;

import regras_negocio.Fachada;

public class Consultar {

	public Consultar() {
		try {
			Fachada.inicializar();

			System.out.println("consultas... \n");
			System.out.println("\nComponentes com 'Estoque' acima de 15 unidades: ");
			for(Componente comp : Fachada.alugueisModelo("palio"))
				System.out.println(comp);


			System.out.println("\nalugueis finalizados");
			for(Orcamento o : Fachada.alugueisFinalizados())
				System.out.println(o);


			System.out.println("\ncarros que possuem 2 alugueis");
			for(Carro c : Fachada.carrosNAlugueis(2))
				System.out.println(c);


			//System.out.println("clientes que possuem 2 alugueis");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		Fachada.finalizar();
		System.out.println("\nfim do programa !");
	}

	public static void main(String[] args) {
		new Consultar();
	}
}

