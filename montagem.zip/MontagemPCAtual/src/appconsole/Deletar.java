/**********************************
 * IFPB - Curso Superior de Tec. em Sist. para Internet
 * POB - Persistencia de Objetos
 * Prof. Fausto Ayres
 *
 */

package appconsole;


import regras_negocio.Fachada;

public class Deletar {

	public Deletar() {
		try {
			Fachada.inicializar();
			Fachada.excluirCliente("12345678910");		 
			System.out.println("cliente deletado 12345678910");

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		try {
			Fachada.inicializar();
			Fachada.excluirComponente("Fonte");		 
			System.out.println("componente deletado Fonte");

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		Fachada.finalizar();
		System.out.println("\nfim do programa !");
	}

	public static void main(String[] args) {
		new Deletar();
	}
}
