/**********************************
 * IFPB - Curso Superior de Tec. em Sist. para Internet
 * POB - Persistencia de Objetos
 * Prof. Fausto Ayres
 *
 */

package appconsole;

import regras_negocio.Fachada;

public class Cadastrar {

	public Cadastrar() {
		try {
			Fachada.inicializar();
			
			System.out.println("cadastrando cliente...");
			Fachada.criarCliente("Manuel Bandeira","12345678910");
			Fachada.criarCliente("Vinicius de Morais","12345678911");
			Fachada.criarCliente("Ariano Suassuna","12345678912");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		try {
			System.out.println("cadastrando componente...");
			Fachada.criarComponente("Placa-m�e", 787.00, 40);
			Fachada.criarComponente("Processador Core i7", 1491.00, 20);
			Fachada.criarComponente("Mem�ria RAM 16GB", 260.00, 80);
			Fachada.criarComponente("Placa de Video 8GB", 2420.00, 10);
			Fachada.criarComponente("SSD 500GB", 150.00, 50);
			Fachada.criarComponente("Cooler", 90.00, 25);
			Fachada.criarComponente("Fonte", 598.00, 15);
			Fachada.criarComponente("Gabinete", 900.00, 5);
			Fachada.criarComponente("Monitor 29pol", 1120.00, 10);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		try {
			System.out.println("criando orcamento...");
			Fachada.criarOrcamento("15/02/2023","12345678910");
			Fachada.criarOrcamento("16/06/2023","12345678910");
			Fachada.criarOrcamento("17/03/2023","12345678911");
			Fachada.criarOrcamento("18/04/2023","12345678911");
			Fachada.criarOrcamento("19/07/2023","12345678911");
			Fachada.criarOrcamento("21/07/2023","12345678912");
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		Fachada.finalizar();
		System.out.println("\nfim do programa !");
	}


	public static void main(String[] args) {
		new Cadastrar();
	}
}
