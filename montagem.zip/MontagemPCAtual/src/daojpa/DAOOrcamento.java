package daojpa;

import java.util.List;


import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

import modelo.Orcamento;

public class DAOOrcamento extends DAO<Orcamento>  {
	
	
	
	public Orcamento read(Object chave) {
		try {
			String idOrc = (String) chave;
			TypedQuery<Orcamento> q = manager.createQuery("select o from Orcamento o where o.idOrc=:n", Orcamento.class);
			q.setParameter("n", idOrc);
			Orcamento p = q.getSingleResult();
			return p;
		} catch (NoResultException e) {
			return null;
		}
	}

	public List<Orcamento> readAll(){
		TypedQuery<Orcamento> query = manager.createQuery("select o from Orcamento o LEFT JO0IN FETCH o.componentes order by o.idOrc",Orcamento.class);
		return  query.getResultList();
	}
	
	public List<Orcamento> consulta1() {
		
		// Pesquisa Or�amentos pelo m�s
		TypedQuery<Orcamento> q = manager.createQuery("select o from Orcamento o where o.data like '%/06/%'", Orcamento.class);
		return q.getResultList();
	}
}
//	//o ID do Or�amento � usado como campo unico 
//	
//	@Override
//	public Orcamento read (Object chave) {
//		int idOrc = (int) chave;	//casting para o tipo da chave
//		Query q = manager.query();
//		q.constrain(Orcamento.class);
//		q.descend("id").constrain(idOrc);
//		List<Orcamento> resultados = q.execute();
//		if (resultados.size()>0)
//			return resultados.get(0);
//		else
//			return null;
//	}
//	
//	//metodo da classe DAO sobrescrito DAOAluguel para
//	//criar "id" sequencial 
//	public void create(Orcamento obj){
//		int novoid = super.gerarId();	//gerar novo id da classe
//		obj.setId(novoid);				//atualizar id do objeto antes de grava-lo no banco
//		manager.store( obj );
//	}
//		
//	/**********************************************************
//	 * 
//	 * TODAS AS CONSULTAS DE OR�AMENTO
//	 * 
//	 **********************************************************/
//	
//	//Pesquisa Or�amentos pelo m�s
//	
//	public List<Orcamento>  readByMes(String mes) {
//		Query q = manager.query();
//		q.constrain(Orcamento.class);
//		q.descend("data").constrain("/"+mes+"/").contains();
//		return q.execute();
//	}
//	
//	//------------------------------------------------
//
//	//Pesquisa Or�amentos por DATA espec�fica
//	
//	public List<Orcamento>  readByDate(String data) {
//		Query q = manager.query();
//		q.constrain(Orcamento.class);
//		q.descend("data").constrain(data);
//		return q.execute();
//	}
//	
//	//------------------------------------------------
//	
//	//Pesquisa Or�amentos por DATA espec�fica (CORRIGIR)....................
//	
//	public List<Orcamento>  readByCliente(String cpfCli) {
//		Query q = manager.query();
//		q.constrain(Cliente.class);
//		q.descend("cpf").constrain(cpfCli);
//		return q.execute();
//		
//		
//		//PRECISA RETORNAR A LISTA DE OR�AMENTOS DO CLIENTE
//		
//	}
//	
//	//------------------------------------------------
//	
//	
//	
//}
