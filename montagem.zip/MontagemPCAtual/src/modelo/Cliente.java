package modelo;

import java.util.ArrayList;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Cliente {

	@Id
	private String cpf;
	private String nome;
	@OneToMany(mappedBy = "cliente", cascade={CascadeType.PERSIST, CascadeType.MERGE},
			fetch = FetchType.LAZY)
	private List<Orcamento> orcamentos = new ArrayList<>();

	
	public Cliente(String cpf, String nome) {
		this.cpf = cpf;
		this.nome = nome;
	}

	public Cliente() {}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

//	public List<Aluguel> getAlugueis() {
//		return alugueis;
//	}
	public List<Orcamento> listarOrcamentos() {
		return orcamentos;
	}

//	public void adicionar(Aluguel a){
//		alugueis.add(a);
//	}
	public void adicionar(Orcamento orc){
		orc.setCliente(this);
		this.orcamentos.add(orc);
	}

//	public void remover(Aluguel a){
//		alugueis.remove(a);
//	}
	public void remover(Orcamento orc){
		orc.setCliente(null);
		this.orcamentos.remove(orc);
	}
	
	public Orcamento localizar(int idOrc) {
	    for (Orcamento orc : orcamentos) {
	        if (orc.getId() == idOrc) {
	            orc.setCliente(this); // Associe o cliente ao or�amento encontrado
	            return orc;
	        }
	 }
	    return null;
	}
	
	
//	@Override
//	public String toString() {
//		String texto = "nome=" + nome + ", cpf=" + cpf;
//		
//		for(Aluguel a : alugueis)
//			texto+= "\n    aluguel: " + a ;
//		
//		return texto;
//	}
	
	@Override
	public String toString() {
		String texto =  "Nome: " +  nome + 
				", CPF: " + cpf;

		texto += ",  Or�amentos: ";
		
		if(orcamentos.size() > 0) {
			for(Orcamento orc : orcamentos)
				if (orc != null) {
					texto += orc.getId() + ", ";
				}
		}

		return texto;
	}


}
