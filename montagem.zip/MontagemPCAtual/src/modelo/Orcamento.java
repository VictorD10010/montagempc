package modelo;

import java.util.List;

import java.util.ArrayList;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
//import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Orcamento {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String data;
	@ManyToOne
    @JoinColumn(name = "cpf")
	private Cliente cliente;
	private Double valor = 0.00;
	
	@ManyToOne
    @JoinColumn(name = "id")
    private Componente componente;
	
    //@OneToMany(mappedBy = "orcamento", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	List<Componente> componentes = new ArrayList<Componente>();
	
	public Orcamento(int id, String data) {
		this.id = id;
		this.data = data;
	}
	
	public Orcamento() {
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public Cliente getCliente() {
		return cliente;
	}
	
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
		cliente.listarOrcamentos().add(this);
	}
	
	public int getId() {
		return id;
	}
	
	public String getData() {
		return data;
	}
	
	public void setData(String data) {
		this.data = data;
	}
	
	public Double getValor() {
		return valor;
	}
	
	public void adicionar(Componente componente){
		this.componentes.add(componente);
		componente.adicionar(this);
		this.valor += componente.getPreco();
	}
	
	public void remover(Componente componente){
		this.componentes.remove(componente);
		componente.remover(this);
		this.valor -= componente.getPreco();
	}
	
	public Componente localizar(String descricao) {
		for (Componente componente : componentes) {
			if (componente.getDescricao() == descricao) {
				return componente;
			}
		}
		return null;
	}
	
	public Componente localizar(int idComp) {
		for (Componente componente : componentes) {
			if (componente.getId() == idComp) {
				return componente;
			}
		}
		return null;
	}
	
	public List<Componente> getComponentes(){
		return componentes;
	}
	
	@Override
	public String toString() {
		String texto = "ID n�: " + id + 
				", Data: " + data +
				", Cliente: " + cliente.getNome() + 
				", Valor: R$ " + valor;
		texto += ", Lista de Pe�as: ";
		for (Componente componente : componentes) {
			texto += componente.getDescricao() + ", ";
		}
		return texto;
	}
	
}
